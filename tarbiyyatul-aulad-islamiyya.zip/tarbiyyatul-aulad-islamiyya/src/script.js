// scripts.js

document.getElementById('registerForm').addEventListener('submit', (event) => {

    event.preventDefault();

    // Collect form data

    const formData = new FormData();

    formData.append('profilePicture', document.getElementById('profilePicture').files[0]);

    formData.append('fullName', document.getElementById('fullName').value);

    formData.append('phoneNumber', document.getElementById('phoneNumber').value);

    formData.append('username', document.getElementById('username').value);

    formData.append('password', document.getElementById('password').value);

    formData.append('dob', document.getElementById('dob').value);

    formData.append('studentNumber', document.getElementById('studentNumber').value);

    // Simulate form submission (replace with actual API call)

    console.log('Registering:', Object.fromEntries(formData.entries()));

    alert('Registration successful!');

});

document.getElementById('loginForm').addEventListener('submit', (event) => {

    event.preventDefault();

    // Collect form data

    const username = document.getElementById('loginUsername').value;

    const password = document.getElementById('loginPassword').value;

    // Simulate login (replace with actual API call)

    console.log('Logging in:', { username, password });

    alert('Login successful!');

});



// scripts.js

// Function to post a message or update the feed

function postContent() {

    const textarea = document.querySelector('.post-form textarea');

    const fileInput = document.querySelector('.post-form input[type="file"]');

    const posts = document.querySelector('.posts');

    const newPost = document.createElement('div');

    newPost.classList.add('post');

    

    newPost.innerHTML = `

        <p>${textarea.value}</p>

        ${fileInput.files.length > 0 ? '<p>Attachment: ' + fileInput.files[0].name + '</p>' : ''}

    `;

    posts.appendChild(newPost);

    textarea.value = '';

    fileInput.value = '';

}

document.querySelector('.post-form button').addEventListener('click', postContent);

// Function to send a message

function sendMessage() {

    const textarea = document.querySelector('.message-form textarea');

    const fileInput = document.querySelector('.message-form input[type="file"]');

    const messageList = document.querySelector('.message-list');

    const newMessage = document.createElement('div');

    newMessage.classList.add('message');

    

    newMessage.innerHTML = `

        <p>${textarea.value}</p>

        ${fileInput.files.length > 0 ? '<p>Attachment: ' + fileInput.files[0].name + '</p>' : ''}

    `;

    messageList.appendChild(newMessage);

    textarea.value = '';

    fileInput.value = '';

}

document.querySelector('.message-form button').addEventListener('click', sendMessage);

// scripts.js

document.getElementById('sendMessage').addEventListener('click', () => {

    const textarea = document.querySelector('textarea');

    const fileInput = document.querySelector('input[type="file"]');

    const messages = document.querySelector('.messages');

    const messageContent = textarea.value;

    const file = fileInput.files[0];

    // Create message element

    const message = document.createElement('div');

    message.classList.add('message', 'sent');

    message.innerHTML = `

        <p>${messageContent}</p>

        ${file ? `<p>Attachment: ${file.name}</p>` : ''}

    `;

    messages.appendChild(message);

    textarea.value = '';

    fileInput.value = '';

    // Scroll to bottom of chat

    messages.scrollTop = messages.scrollHeight;

});

// Dummy functions for video and audio calls

document.getElementById('videoCall').addEventListener('click', () => {

    alert('Initiating video call...');

});

document.getElementById('audioCall').addEventListener('click', () => {

    alert('Initiating audio call...');

});


// scripts.js

// Handle profile form submission

document.getElementById('profileForm').addEventListener('submit', (event) => {

    event.preventDefault();

    // Collect form data

    const formData = new FormData();

    formData.append('profilePic', document.getElementById('profilePic').files[0]);

    formData.append('fullName', document.getElementById('fullName').value);

    formData.append('phoneNumber', document.getElementById('phoneNumber').value);

    formData.append('username', document.getElementById('username').value);

    formData.append('dob', document.getElementById('dob').value);

    formData.append('studentNumber', document.getElementById('studentNumber').value);

    // Simulate form submission (replace with actual API call)

    console.log('Saving profile:', Object.fromEntries(formData.entries()));

    alert('Profile updated successfully!');

});


// Handle invite form submission

document.getElementById('inviteForm').addEventListener('submit', (event) => {

    event.preventDefault();

    // Collect form data

    const contacts = document.getElementById('contactList').value.split('\n').map(contact => contact.trim()).filter(contact => contact);

    // Simulate sending invites (replace with actual API call)

    console.log('Inviting contacts:', contacts);

    alert('Invitations sent successfully!');

});

